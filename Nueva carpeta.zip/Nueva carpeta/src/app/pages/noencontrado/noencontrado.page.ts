import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-noencontrado',
  templateUrl: './noencontrado.page.html',
  styleUrls: ['./noencontrado.page.scss'],
  standalone: false,  
})
export class NoencontradoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
