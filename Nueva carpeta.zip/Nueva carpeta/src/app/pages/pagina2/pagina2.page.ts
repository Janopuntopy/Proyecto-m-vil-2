import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagina2',
  templateUrl: './pagina2.page.html',
  styleUrls: ['./pagina2.page.scss'],
  standalone: false,
})
export class Pagina2Page implements OnInit {

  CrearUser: any ={
    usuario:"",
    password:""
  }

  constructor() { }

  ngOnInit() {
  }

}
