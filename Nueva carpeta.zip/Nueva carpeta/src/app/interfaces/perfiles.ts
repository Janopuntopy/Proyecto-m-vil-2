export interface Perfiles {
    nombreUsusario: string;
    contraseñaUsuario: string;
    correoUsuario: string;
    telefonoUsuario: number;

}
