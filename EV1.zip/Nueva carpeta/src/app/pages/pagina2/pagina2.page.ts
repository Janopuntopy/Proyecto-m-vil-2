import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-pagina2',
  templateUrl: './pagina2.page.html',
  styleUrls: ['./pagina2.page.scss'],
  standalone: false,
})
export class Pagina2Page implements OnInit {

  CrearUser: any ={
    usuario:"",
    password:""
  }

  constructor(private toastController: ToastController, private router:Router) { }

  ngOnInit() {
  }

  
  Creacion(){
    console.log(this.CrearUser)
    this.presentToast('top',"Iniciando sesión..."+this.CrearUser.usuario)
    this.router.navigate(['/inicio'])
  }

    async presentToast(position: 'top' | 'middle' | 'bottom', msg : string, duration?:number ){
    const toast = await this.toastController.create({
      message : msg,
      duration: duration?duration:1500,
      position : position,
    });

    await toast.present();
    
  }
}
