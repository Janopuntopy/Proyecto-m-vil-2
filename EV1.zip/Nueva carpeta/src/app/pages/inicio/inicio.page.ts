import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertController, ToastController } from '@ionic/angular';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.page.html',
  styleUrls: ['./inicio.page.scss'],
  standalone: false,
})
export class InicioPage implements OnInit {

  //declarar un modelo para validar [diccionario (key,value)]
  login: any ={
    usuario:"",
    password:""
  }


  //defino una variable global para guardar el nombre(key) del campo no ingresado


  constructor(private toastController: ToastController, private router:Router,private fb: FormBuilder, private alertCtrl: AlertController) { }

  ngOnInit() {
    
  }
  //validateModel sirve para validar que singrese algo en los campos del html medieante su modelo

  iniciar(){
    console.log(this.login)
    this.presentToast('top',"Iniciando sesión..."+this.login.usuario)
    this.router.navigate(['/home'])
  }

  async presentToast(position: 'top' | 'middle' | 'bottom', msg : string, duration?:number ){
    const toast = await this.toastController.create({
      message : msg,
      duration: duration?duration:1500,
      position : position,
    });

    await toast.present();
    
  }
}
